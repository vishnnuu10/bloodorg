import { Button } from '@mui/material'
import React from 'react'
import { Link } from 'react-router-dom'

const Donordashboard = () => {
  return (
    <div>
      <br></br><br></br>

      <Link to= {'/req'}>
         <Button variant='contained' color="error">Request</Button>
       
         </Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <Link to= {'/dnr'}>
         <Button variant='contained' color="error">Donate</Button>
       
         </Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <Link to= {'/usrdnr'}>
         <Button variant='contained' color="error">Donor List</Button>
       
         </Link>








    </div>
  )
}

export default Donordashboard